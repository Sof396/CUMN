
package com.example.cumn;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class masInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mas_info);
    }
}